<?php
/**
 * Template Name: Frontpage
 *
 * Displays the Home page.
 *
 * @package designexo
 */
?>

<?php

get_header(); 

do_action( 'arileextra_designexo_frontpage', false);
	
?>
<?php get_footer(); ?>
